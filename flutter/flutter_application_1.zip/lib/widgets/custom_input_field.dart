import 'package:flutter/material.dart';
import 'package:flutter_application_1/themes/theme.dart';

class CustomInputField extends StatelessWidget {
  final String description;
  final String header;
  final String footer;
  final dynamic icono;
  final dynamic type;
  final bool auto;
  final bool tex;

  const CustomInputField({
    Key? key,
    required this.description,
    required this.header,
    required this.footer,
    required this.icono,
    required this.type,
    required this.auto,
    required this.tex,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      autofocus: auto,
      keyboardType: type,
      obscureText: tex,
      textCapitalization: TextCapitalization.words,
      decoration: InputDecoration(
        hintText: description,
        labelText: header,
        helperText: footer,
        suffixIcon: Icon(
          icono,
          color: Color.fromARGB(150, 14, 49, 209),
        ),
        icon: Icon(
          icono,
          color: Color.fromARGB(255, 94, 76, 175),
        ),
      ),
    );
  }
}
