import 'package:flutter/material.dart';
import 'package:flutter_application_1/widgets/widgets.dart';

class UserFormScreen extends StatelessWidget {
  const UserFormScreen({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Formulario'),
        backgroundColor: const Color.fromARGB(255, 44, 186, 230),
        elevation: 5,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(children: [
          const CustomInputField(
            description: "Escriba su Nombre",
            header: "Nombre",
            footer: "Nombre Completo",
            icono: Icons.person_add_alt,
            type: TextInputType.text,
            auto: true,
            tex: false,
          ),
          const CustomInputField(
            description: "Escriba su Apellido",
            header: "Apellido",
            footer: "Apellido Completo",
            icono: Icons.person_add_alt,
            type: TextInputType.text,
            auto: true,
            tex: false,
          ),
          const CustomInputField(
            description: "Escriba su Numero de Telefono",
            header: "Telefono",
            footer: "Escriba el numero con el codigo del pais",
            icono: Icons.phone_android,
            type: TextInputType.number,
            auto: true,
            tex: false,
          ),
          const CustomInputField(
            description: "Escriba su Correo",
            header: "Correo",
            footer: "Se le Enviara un Codigo de Validacion",
            icono: Icons.mail,
            type: TextInputType.text,
            auto: true,
            tex: false,
          ),
          const CustomInputField(
            description: "Escriba su Contraseña",
            header: "Contraseña",
            footer: "Debe contener caracteres especiales",
            icono: Icons.password_rounded,
            type: TextInputType.text,
            auto: true,
            tex: true,
          ),
          RaisedButton(
            child: Text("Enviar"),
            color: Colors.blueAccent,
            onPressed: () {
              Navigator.pushNamed(context, 'user-list');
            },
          ),
        ]),
      ),
    );
  }
}
