import 'package:flutter/material.dart';

class UserListScreen extends StatelessWidget {
  const UserListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Usuarios'),
        backgroundColor: Color.fromARGB(255, 50, 143, 219),
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: <Widget>[
          Container(
            height: 50,
            child: RaisedButton(
              color: Colors.amber[600],
              onPressed: () {
                Navigator.pushNamed(context, 'user-form');
              },
              child: const Text('Juan Perez'),
            ),
          ),
          Container(
            height: 50,
            child: RaisedButton(
              color: Colors.amber[500],
              onPressed: () {
                Navigator.pushNamed(context, 'user-form');
              },
              child: const Text('Antonio Guerra'),
            ),
          ),
          Container(
            height: 50,
            child: RaisedButton(
              color: Colors.amber[400],
              onPressed: () {
                Navigator.pushNamed(context, 'user-form');
              },
              child: const Text('Matias Yepez'),
            ),
          ),
          Container(
            height: 50,
            child: RaisedButton(
              color: Colors.amber[300],
              onPressed: () {
                Navigator.pushNamed(context, 'user-form');
              },
              child: const Text('Julian Guerra'),
            ),
          ),
          Container(
            height: 50,
            child: RaisedButton(
              color: Colors.amber[200],
              onPressed: () {
                Navigator.pushNamed(context, 'user-form');
              },
              child: const Text('Jessica Jones'),
            ),
          ),
        ],
      ),
    );
  }
}
